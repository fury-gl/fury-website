"""
===================
Quick Visualization
===================

This example demonstrates how to use the visualization function to quickly display
3D actors in a window.

"""

import numpy as np

from fury.window import show
from fury.actor import sphere

###############################################################################
# Let's create sphere actor to add three spheres to display.

sphere_actor = sphere(
    np.asarray([(15, 0, 0), (0, 15, 0), (0, 0, 15)]).reshape((3, 3)),
    radii=15,
    colors=np.asarray([(1, 0, 0), (0, 1, 0), (0, 0, 1)]).reshape((3, 3)),
    phi=48,
    theta=48,
)


show(actors=[sphere_actor])
